export interface Product {
  _id: number;
  productName: string;
  productCategory: string;
  price : number;
  productImage : string,
  specification : string,
  description : string,
}
