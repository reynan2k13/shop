import { Component } from '@angular/core';

@Component({
  selector: 'app-product-list',
  templateUrl: 'app/product-list/product-list.component.html',
  styleUrls: ['app/product-list/product-list.component.css']
})
export class ProductListComponent {
  
  share() {
    window.alert('The product has been shared!');
  }
}
