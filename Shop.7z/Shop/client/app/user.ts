export interface User {
  _id: number;
  username: string;
  userId : number;
  cart : any;
}
