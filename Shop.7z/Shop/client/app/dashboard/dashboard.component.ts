import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { Product } from '../product';

@Component({
  selector: 'app-dashboard',
  templateUrl: 'app/dashboard/dashboard.component.html',
  styleUrls: [ 'app/dashboard/dashboard.component.css' ]
})


export class DashboardComponent implements OnInit {
  
  products : Product[] = [];

  constructor(private http: Http) {}
  ngOnInit() {
    this.getProduct();
  }

  getProduct(): void {
    this.http.get('/products')
      .subscribe( products => {
        const transformedData = Object.keys(products).map(key => products[key]);
        this.products = JSON.parse( transformedData[0] );
      })
  }
}
