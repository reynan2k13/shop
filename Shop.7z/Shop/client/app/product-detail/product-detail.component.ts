import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { Product } from '../product';

@Component({
  selector: 'app-product-detail',
  templateUrl: 'app/product-detail/product-detail.component.html',
  styleUrls: [ 'app/product-detail/product-detail.component.css' ]
})


export class ProductDetailComponent implements OnInit {
  
  product : Product[] = [];

  constructor(private http: Http) {}
  ngOnInit() {
    this.getProductById();
  }

  getProductById(): void {
    console.log("window.location.href", window.location.href)
    const location = window.location.href;
    const id = location.split("/").pop();
    this.http.get('/products/'+ id)
      .subscribe( products => {
        const transformedData = Object.keys(products).map(key => products[key]);
        this.product = JSON.parse( transformedData[0] );
      })
  }

  addCart(product) {
    console.log("addTocart", product)
    const userId : number = 1; //defaultid
    this.http.put('/addCart/'+ userId , product)
      .subscribe( products => {
        console.log('add to cart', products)
      })
  }
}
