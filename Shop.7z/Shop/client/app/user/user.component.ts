import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { User } from '../user';

@Component({
  selector: 'user',
  templateUrl: 'app/user/user.component.html',
  styleUrls: [ 'app/user/user.component.css' ]
})


export class UserComponent implements OnInit {
  
  user : User[] = [];

  constructor(private http: Http) {}
  ngOnInit() {
    this.getUser();
  }

  getUser() {
    console.log("get user info")
    const userId : number = 1; //defaultid
    this.http.get('/addCart/'+ userId)
      .subscribe( user => {
        const transformedData = Object.keys(user).map(key => user[key]);
        this.user = JSON.parse( transformedData[0] );
      })
  }

}
