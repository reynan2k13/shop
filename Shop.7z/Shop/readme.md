SHOP EXAM

Getting Started

Installing Dependencies

Node
- Follow instructions to install the latest version of node for your platform in the Node docs (https://nodejs.org/en/)

MongoDB
- install mongo DB (https://docs.mongodb.com/manual/installation/#mongodb-community-edition-installation-tutorials)
- setup your local mongoDB environtment
- run mongo db
- create collection products
    - insert this to collection products
    {
        "_id" : ObjectId("5ff47abe8d5adce53ee4bacd"),
        "productName" : "coffee",
        "productCategory" : "drink",
        "price" : 200,
        "productImage" : "/src/images/coffee.jpg",
        "specification" : "specification",
        "description" : "description"
    },
    {
        "_id" : ObjectId("5ff47d968d5adce53ee4bace"),
        "productName" : "milk",
        "productCategory" : "drink",
        "price" : 200,
        "productImage" : "/src/images/milk.jpg",
        "specification" : "specification",
        "description" : "description"
    },
    {
        "_id" : ObjectId("5ff57f8b8d5adce53ee4bacf"),
        "productName" : "milk",
        "productCategory" : "drink",
        "price" : 200,
        "productImage" : "/src/images/milk.jpg",
        "specification" : "specification",
        "description" : "description"
    },
    {
        "_id" : ObjectId("5ff57f918d5adce53ee4bad0"),
        "productName" : "milk",
        "productCategory" : "drink",
        "price" : 200,
        "productImage" : "/src/images/milk.jpg",
        "specification" : "specification",
        "description" : "description"
    },
    {
        "_id" : ObjectId("5ff57f968d5adce53ee4bad1"),
        "productName" : "milk",
        "productCategory" : "drink",
        "price" : 200,
        "productImage" : "/src/images/milk.jpg",
        "specification" : "specification",
        "description" : "description"
    },
    {
        "_id" : ObjectId("5ff57f9b8d5adce53ee4bad2"),
        "productName" : "milk",
        "productCategory" : "drink",
        "price" : 200,
        "productImage" : "/src/images/milk.jpg",
        "specification" : "specification",
        "description" : "description"
    },
    {
        "_id" : ObjectId("5ff57fa28d5adce53ee4bad3"),
        "productName" : "milk",
        "productCategory" : "drink",
        "price" : 200,
        "productImage" : "/src/images/milk.jpg",
        "specification" : "specification",
        "description" : "description"
    },
    {
        "_id" : ObjectId("5ff5a41e8d5adce53ee4bad4"),
        "productName" : "coffee",
        "productCategory" : "drink",
        "price" : 200,
        "productImage" : "/src/images/coffee.jpg",
        "specification" : "specification",
        "description" : "description"
    }

- create collection users
    - insert this to collection users
    {
    "_id" : ObjectId("5ff5ae078d5adce53ee4bad5"),
    "userId" : 1,
    "username" : "Reynan",
    "cart" : []
    }

- npm Dependencies
Once you have your node environment setup and running, install dependencies by navigating to the root directory and running:
    npm install
This will install all of the required packages we selected within the package.json file.

-Running the server
    npm start

- open your browser the go to http://localhost:3000

**note
    - there is some error in the console when you run the npm start, this is some error in the angular dependencies when running the gulp. This project i seperate the client side and the server side but they share one node_modules.

