const mongoose     = require('mongoose');
const Schema       = mongoose.Schema;

const UsersSchema   = new Schema({
	userId : {type : Number},
	name : {type : String},
	cart : {type : Array}
}, { versionKey: false });

module.exports = mongoose.model('Users', UsersSchema);