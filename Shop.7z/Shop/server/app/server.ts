import express = require('express');
import path = require('path');
import bodyParser = require ('body-parser');

(async () => {
    try {
        const app : any = express();
        const port: number = 3000;
 
        app.use(express.static('./client'));
        app.use('/node_modules', express.static('./node_modules'));
        
        // setup the view engine that will be use
        let reqPath = path.join(__dirname, '../../')
        app.set('views', path.join(reqPath, './client/src/views'));
        app.set('view engine', 'pug');
        app.use(bodyParser.urlencoded({ extended: true }));
        app.use(bodyParser.json());


        //database
        const mongoose = require('mongoose');
        const dbPath = 'mongodb://localhost:27017/test';
        const options = {useNewUrlParser: true, useUnifiedTopology: true}
        const mongo = mongoose.connect(dbPath, options);
        mongo.then(() => {
            console.log('connected');
        }, error => {
            console.log(error, 'error');
        })
        const Products = require('./models/products'); // Products model
        const Users = require('./models/users'); // users model
        const router = express.Router();
        
        // routes
        app.get('/', (req : any , res : any)=>{
            return res.render('main', {data : 'test'})
        })

        router.use((req, res, next) => {
            console.log('Event triggered.');
            next();
        });

        // get all products
        router.route('/products')
            .get((req, res) => {
                Products.find((err, products) => {
                    if (err) res.send(err);
                    res.send(
                        products,
                    );
                });
            });
        
        // get products by id
        router.route('/products/:product_id')
            .get((req, res) => {
                Products.findById(req.params.product_id, (err, product) => {
                    if (err) res.send(err);
                    res.send(
                        product,
                    );
                });
            })
        
        router.route('/addCart/:userId')
            // add cart
            .put((req, res) => {
                Users.findOne({userId : req.params.userId}, (err, users) => {
                    if (err) res.send(err);
                    users.cart.push(req.body);
                    users.save(err => {
                        if (err){ res.send(err);
                            res.send('success');
                        } 
                    });
                });
            })
            // get user cart
            .get((req, res) => {
                Users.findOne({userId : req.params.userId}, (err, userInfo) => {
                    if (err) res.send(err);
                        res.send(
                            userInfo,
                        );
                });
            })
        

        app.use('/', router);

        // Start the server
        app.listen(port , () => {
            console.info(`Server listening on port ${port}`);
        });
        
        return true;
    } catch (e) {
        console.error(e, '[LOADERS CATCH ERROR]', 'server/app/server.ts');
        return e;
    }
})()
    .catch((e) => {
        console.error(e, '[SERVER CATCH ERROR]', 'server/app/server.ts');
        process.exit(1);
    });

